<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->model('Student_model');
        $this->load->model('Auth_model');
		$this->load->library('session');
		$this->load->helper('file');
    }
    /**
     * Index Page
     */
    public function index()
    {
        if(is_author()){
		  
        }else{
			redirect('login');
		}
        $data['title'] = "dashboard";
        $id = $this->session->userdata('id');
        $data['post_count'] = count($this->post_model->get_posts_backend());
        $data['pending_post_count'] = count($this->post_model->get_pending_posts());
        $data['video_count'] = count($this->video_model->get_videos_backend());
        $data['pending_video_count'] = count($this->video_model->get_pending_videos());
        $data['teacher_sub'] = $this->Student_model->get_teacher($id);
       if($data['teacher_sub']){
        $data['user_detail'] = $this->Student_model->user_detail($data['teacher_sub'][0]['id']);
        $data['teacher_detail'] = $this->Student_model->teacher_detail($data['teacher_sub'][0]['id']);
       }
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/index', $data);
        $this->load->view('admin/includes/_footer');
    }


    public function teacher_detail()
    {
        $data['title'] = "Book";
        $id = $this->input->get('id');
        $sid = $this->session->userdata('id');
        $data['user_detail'] = $this->Student_model->user_detail($id);
        $data['teacher_detail'] = $this->Student_model->teacher_detail($id);
        $data['basic_detail'] = $this->Student_model->basic_detail($id);
        $data['lesson']  = $this->Student_model->lesson_detail($id);
        $studentDetail = $this->Student_model->sdetail($sid);
        $data['studentCountry'] = $studentDetail[0]['live_country'];
        if($data['studentCountry'] !== "United States"){
            // get student country currency code API
            $string = read_file('https://restcountries.eu/rest/v2/name/'.$data['studentCountry']);
            $explode = explode('"',$string);
            // var_dump($explode[89]);
            $data['currencySymbol'] = $explode[89];
            // get student country currency rate by currency code
            $studentCurrency = read_file('https://free.currconv.com/api/v7/convert?q=USD_'.$explode[81].'&compact=ultra&apiKey=42af8904c81dd07008f4');
            $currencyRate = preg_split("/[:}]+/", $studentCurrency);
            $data['currencyRate'] = $currencyRate[1];
            // var_dump($data['currencyRate']);
        }
        $data['education'] = $this->Student_model->teacher_edu_info($id);
        $data['certificate'] = $this->Student_model->certificate_tech_coun($id);
        $data['work'] = $this->Student_model->teacher_work_info($id);
        $data['average_score'] = $this->Student_model->lesson_avg($id);
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/teacher_book', $data);
        $this->load->view('admin/includes/_footer'); 
    }

    public function profile(){
        $data['title'] = "profile";
        $id = $this->session->userdata('id');
        $data['user_detail'] = $this->Student_model->user_detail($id);
        $data['sdetail'] = $this->Student_model->sdetail($id);
        $data['teacher_sub'] = $this->Student_model->get_teacher_profile($id);
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/profile');
        $this->load->view('admin/includes/_footer');
    }

    public function lesson(){
        $data['title'] = "lesson";
        $id = $this->session->userdata('id');
        
        $data['user_detail'] = $this->Student_model->user_detail($id);
        $data['lesson'] = $this->Student_model->book_lesson($id);
        // $data['teacher_img'] = $this->Student_model->teacher_img($id);
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/lesson');
        $this->load->view('admin/includes/_footer');
    }

    public function teacher_fav(){
        $data['title'] = "Teacher";
        $id = $this->session->userdata('id');
        $data['teacher_sub'] = $this->Student_model->get_teacher($id);
        if(!empty($data['teacher_sub'])){
        $data['user_detail'] = $this->Student_model->user_detail($data['teacher_sub'][0]['id']);
        $data['teacher_detail'] = $this->Student_model->teacher_detail($data['teacher_sub'][0]['id']);
        $data['lesson']  = $this->Student_model->lesson_detail($data['teacher_sub'][0]['id']);
        $data['lesson_avg']  = $this->Student_model->lesson_avg($data['teacher_sub'][0]['id']);
        }
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/teacher',$data);
        $this->load->view('admin/includes/_footer');
    }

    public function referral(){
        $data['title'] = "Referral";
        $id = $this->session->userdata('id');
        $data['value'] = $this->Student_model->refer_detail($id);
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/referral',$data);
        $this->load->view('admin/includes/_footer');
    }

    public function refer_frnd(){
        $id = $this->session->userdata('id');
        $value = $this->Student_model->refer_detail($id);
        $email = $this->input->post('referred_email', true);
        if($value){
        if($value[0]['referred_email']  != $email){
            $data = array(
                'referred_email' => $email,
                'referrer_id' => $id,
            );	
           
            $refer = $this->Student_model->refer_frnd($data);
            if($refer){
                print "<script type=\"text/javascript\">alert('You refer your friend Successfully!');
                window.location.href='referral';</script>";
            } else {
                //error
                $this->session->set_flashdata('error', html_escape(trans("refer_frnd_error")));
                redirect($this->agent->referrer());
            } 
        }
        else{
          //  $new = $this->session->set_flashdata('error', trans("prev_refer_frnd"));
           // var_dump($value[0]['referred_email']  != $email  ,$new);
           print "<script type=\"text/javascript\">alert('You already refer to this email');
           window.location.href='referral';</script>";
        }
        }  
        else
        {
            $data = array(
                'referred_email' => $email,
                'referrer_id' => $id,
            );	
            $refer = $this->Student_model->refer_frnd($data);
            if($refer){
                $this->session->set_flashdata('error', trans("refer_frnd"));
                redirect($this->agent->referrer());
            } else {
                //error
                $this->session->set_flashdata('error', trans("refer_frnd_error"));
                redirect($this->agent->referrer());
            }
        } 
    }

    public function Buy(){
        $data['title'] = "Buy Credit";
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/payment',$data);
        $this->load->view('admin/includes/_footer');
    }

    
    public function teacher_search()
    {
        $data['title'] = "Search";
        $data['teacher_sub'] = $this->Student_model->teacher_search();
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/teacher_search', $data);
        $this->load->view('admin/includes/_footer'); 
    }

    public function edit_profile(){
        $data['title'] = "profile";
        $id = $this->input->get('id');
        $data['country']  = $this->auth_model->country();
        $data['user_detail'] = $this->Student_model->user_detail($id);
        $data['sdetail'] = $this->Student_model->sdetail($id);
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/edit_profile');
        $this->load->view('admin/includes/_footer');
    }

    public function add_user_detail(){
        $id= $this->input->post('user_id', true);
        $data = array(
            'user_id' =>  $id,
            'birth_year' => $this->input->post('birth_year', true),
            'birth_month' => $this->input->post('birth_month', true),
            'birth_day' => $this->input->post('birth_day', true),
            'from_country' => $this->input->post('from_country', true),
            'live_country' => $this->input->post('live_country', true),
            'live_state' => $this->input->post('live_state', true),
            'time_zone' => $this->input->post('time_zone', true),
            'native_lang' => $this->input->post('native_lang', true),
            'speak_lang' => $this->input->post('speak_lang', true),
            'speak_lang_level' => $this->input->post('speak_lang_level', true),
            'learning' => $this->input->post('learning', true),
            'primary' => $this->input->post('primary', true),
            'speak_lang2' => $this->input->post('speak_lang2', true),
            'speak_lang_level2' => $this->input->post('speak_lang_level2', true),
            'learning2' => $this->input->post('learning2', true),
            'primary2' => $this->input->post('primary2', true),
            'comm_tool' => $this->input->post('comm_tool', true),
            'comm_id' => $this->input->post('comm_id', true),
            'intro' => $this->input->post('intro', true),
        );	
        $user = $this->Student_model->student_info($data);
        $this->Auth_model->update_avtar($id);
        if($user) {
            redirect($this->agent->referrer());
        } else {
            //error
            $this->session->set_flashdata('error', trans("User Registration is not Added"));
            redirect($this->agent->referrer());
        }
    }

    public function edit_user_detail()
    {
        $id= $this->input->post('user_id', true);
        $this->Auth_model->update_avtar_student($id);
        $data = array(
            'user_id' =>  $this->input->post('user_id', true),
            'birth_year' => $this->input->post('birth_year', true),
            'birth_month' => $this->input->post('birth_month', true),
            'birth_day' => $this->input->post('birth_day', true),
            'from_country' => $this->input->post('from_country', true),
            'live_country' => $this->input->post('live_country', true),
            'live_state' => $this->input->post('live_state', true),
            'time_zone' => $this->input->post('time_zone', true),
            'native_lang' => $this->input->post('native_lang', true),
            'speak_lang' => $this->input->post('speak_lang', true),
            'speak_lang_level' => $this->input->post('speak_lang_level', true),
            'learning' => $this->input->post('learning', true),
            'primary' => $this->input->post('primary', true),
            'speak_lang2' => $this->input->post('speak_lang2', true),
            'speak_lang_level2' => $this->input->post('speak_lang_level2', true),
            'learning2' => $this->input->post('learning2', true),
            'primary2' => $this->input->post('primary2', true),
            'comm_tool' => $this->input->post('comm_tool', true),
            'comm_id' => $this->input->post('comm_id', true),
            'intro' => $this->input->post('intro', true),
        );	
        $user = $this->Student_model->edit_user_detail($id,$data);
        if($user) {
            redirect($this->agent->referrer());
        } else {
            //error
            $this->session->set_flashdata('error', trans("User Registration is not Added"));
            redirect($this->agent->referrer());
        }
    }

    public function book(){
        
        if(is_admin() or is_author()){
		  
        }else{
			redirect('login');
        }
        
        $data['title'] = "Book";
        
        $id = $this->session->userdata('id');
        $teacher_id= $this->input->get('id');
        $data['user_detail'] = $this->Student_model->user_detail($id);
        $data['lesson']  = $this->Student_model->lesson_detail($teacher_id);
        $data['events']  = $this->Student_model->events($teacher_id);
        $data['teacher_id'] =$teacher_id;
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('student/book');
        $this->load->view('admin/includes/_footer');
    }

    public function add_book(){
        $id = $this->session->userdata('id');
        $teacher_id = $this->input->post('teacher_id', true);     
        $lesson_id = $this->input->post('lesson_id', true);     
        if(!empty($lesson_id)){
        $data = array(
            'teacher_id' => $teacher_id,
            'lesson_id'  => $lesson_id,
            'student_id' =>  $id,
        );
        $user = $this->Student_model->add_book($data);
        $booking = array(
            'teacher_id' => $teacher_id,
            'student_id' =>  $id,
        );
        $this->db->insert('booking_student',$booking);
        redirect(base_url('student/book?id='.$teacher_id.'&page=Book-Now&book_id='.$user.'&lesson_id='.$lesson_id));
        }
        else{
            redirect($this->agent->referrer());
        }
    }
    public function update_book(){
        $book_id = $this->input->post('book_id', true);
        $lesson_id = $this->input->post('lesson_id');
        $stripe_data = ['book_id'=>$book_id,'lesson_id'=>$lesson_id,];
        // var_dump($ids);
        $data = array(
            'event_id'  => $this->input->post('event_id', true),
        );
        $user = $this->Student_model->update_book($book_id,$data);
        $this->session->set_userdata($stripe_data);
        // var_dump ($this->session->flashdata('lesson_price'));
        $this->session->set_flashdata('success', "Details Added successfully.");
        // redirect($this->agent->referrer());
        redirect('StripeController/index');
    }

    public function student_contact(){
        $data = array(
            'teacher_id' => $this->input->post('teacher_id'),
            'user_id' => $this->input->post('student_id'),
            'teacher_reason' => $this->input->post('teacher_reason'),
            'teachingplan' => $this->input->post('teachingplan'),
            'lesson_length' => $this->input->post('lesson_length'),
            'specific_area' => $this->input->post('specific_area'),
            'language_prof' => $this->input->post('language_prof'),
            'teacher_material' => $this->input->post('teacher_material'),
            'time_prefer' => $this->input->post('time_prefer'),
            'fsq' => $this->input->post('fsq'),   
        );
        $user = $this->Student_model->insert_st_contact($data);
        $this->session->set_flashdata('success', "Details Added successfully.");
        redirect($this->agent->referrer());
    }
}
