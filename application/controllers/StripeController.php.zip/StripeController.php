<?php
defined('BASEPATH') OR exit('No direct script access allowed');
   
class StripeController extends MY_Controller {
    
    /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {
       parent::__construct();
       $this->load->library("session");
       $this->load->model('Student_model');
       $this->load->helper('url');
    }
    
    /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function index()
    {
        $book_id = $this->session->userdata('book_id');
        // $lesson_id = $this->session->userdata('lesson_id');
        $id = $this->session->userdata('id');
        $data['user_detail'] = $this->Student_model->user_detail($id);
        $data['lesson'] = $this->Student_model->get_lesson($book_id);
        
        
        
        
        // var_dump($lessonPrice);
        // var_dump($data['lesson']);
        $this->load->view('admin/includes/_header', $data);
        $this->load->view('my_stripe');
        $this->load->view('admin/includes/_footer');
    }
       
    /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function stripePost()
    {
        $lesson_id = $this->session->userdata('lesson_id');
        $lessonPrice = $this->Student_model->lesson_price($lesson_id);
        $Amount = $lessonPrice[0]['total_price'];
    
        require_once('application/libraries/stripe-php/init.php');
    
        \Stripe\Stripe::setApiKey($this->config->item('stripe_secret'));
        $stripe = \Stripe\Charge::create ([
                "amount" =>  $Amount * 100,
                "currency" => "usd",
                "source" => $this->input->post('stripeToken'),
                "description" => "Test payment from Mylangauge.com." 
        ]);
      if($stripe){
      $this->session->set_flashdata('success', 'Payment made successfully.');
      $book_id = $this->input->post('book_id');
      $data = array('payment_status' => true, 'data'=> $stripe);
      $data['lesson'] = $this->Student_model->get_lesson_update($book_id,$Amount,$data);

      
      
      redirect(base_url('student'));
                
      }
    }
}